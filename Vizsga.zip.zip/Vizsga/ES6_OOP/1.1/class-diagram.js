class NumberSequence {
    constructor(start, end){
        this.start = start,
        this.end = end,
        this.current = start
    }

    next(){
        if(this.current < this.end) {
            this.current += 1
            return this.current
        }
        return undefined
    }
};


class EvenNumberSequence {
    constructor(start, end){
        this.start = start,
        this.end = end,
        this.seq = new NumberSequence(start, end)
    }
    
    next(){
        if(this.seq.next()%2){
            this.seq.next()
        }
        if(this.seq.next()>this.end) return undefined
    }
};


class CustomNumberSequence {
    constructor(start, end, func){
        this.start = start,
        this.end = end,
        this.seq = new NumberSequence(start, end),
        this.next = func(this.seq.current)
    }

    next(){
        if(this.seq.current < this.next){
            this.seq.next()
            this.next()
        }
        if(this.seq.next()>this.end) return undefined
        return this.seq.current
    }
}