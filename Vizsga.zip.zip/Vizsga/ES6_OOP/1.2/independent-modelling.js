class LaciKonyha {
    constructor(){
        this.max = 10,
        this.current = 0,
        this.guests = [],
        this.storage = {
            meat= 5,
            vegetable = 20,
            flour = 1,
        }
        this.receipt ={
            soup = {
                vegetable: 1,
                flour: 1,
            },
            meatSoup = {
                meat: 2,
                flour: 1
            }
        }
    }

    guestArrives(name){
        if(this.current === 10) return
        this.current += 1
        this.guests.push(name)
    }

    guestLeaves(name){
        this.current -= 1
        this.guests.find(name)
    }

    order(foodName, guestName){
        if(!(this.guests.find(guestName))) return false
        if(!((Object.key(this.receipt).find(foodName)))) return false
        const orderedReceipt = Object.key(this.receipt).find(foodName)
        Object.keys(orderedReceipt)
    }

    
}

class Guest {
    constructor(name){
        this.name = name
    }
    order(foodName, restaurant){
        restaurant.order(foodName, this.name)
    }
}