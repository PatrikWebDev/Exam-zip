const ADDUSER = 'ADDUSER';
const ADDQUESTION = 'ADDQUESTION';
let counter = 0

function addUser(user) {
    return {
        type: ADDUSER,
        user
    }
}

function addQuestion(username, title, text, tags) {
    counter += 1
    return {
        type: ADDUSER,
        question:{
            id: counter,
            asker: username,
            title: title,
            text: text,
            tags: tags
        }
    }
}


export {addUser, ADDUSER, ADDQUESTION, addQuestion}