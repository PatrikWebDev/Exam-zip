import React, {Component} from 'react'
import {addQuestion} from './action';
import { connect } from 'react-redux';

class Questions extends Component{
    render(){
        return(
            <div>
                <form>
                    <input id="title" type="text"></input>
                    <input id="text" type="text"></input>
                    <input id="tags" type="text"></input>
                    <input id="userName" type="hidden" value={this.props.user[0]} ></input>
                     <button type="button" onClick={ () => {this.props.addQuestion(document.getElementById("userName").value,
                    document.getElementById("title").value,
                    document.getElementById("text").value,
                    document.getElementById("tags").value)}}>Ask</button>
                </form>
                    {this.props.question.map(question=>{
                    return(
                        <div>
                            <h4>{question.title}</h4>
                            <p>{question.asker}</p>
                            <p>{question.text}</p>
                            <p>{question.tags}</p>
                        </div>
                    )
                })}
            </div>
        )
    }
}

function mapStateToProps(state){
    return {...state}
}

function mapDispatchToProps(dispatch) {
    return {
        addQuestion: (username, title, text, tags) => dispatch(addQuestion(username, title, text, tags)),
      }
}

export default connect(mapStateToProps, mapDispatchToProps)(Questions)