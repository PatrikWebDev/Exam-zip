import React from 'react';
import {
  BrowserRouter as Router,
  Switch,
  Route,
} from "react-router-dom";
import './App.css';
import Home from './home.js'
import Questions from './questions';
import Myquestions from './myquestions';

function App() {
  return (
    <Router>
      <Switch>
      <Route path="/myquestions">
        <Myquestions />
      </Route>
      <Route path="/newuser">
        <Home />
      </Route>
        <Route path="/">
          <Questions />
        </Route>
      </Switch>
  </Router>
  );
}

export default App;
