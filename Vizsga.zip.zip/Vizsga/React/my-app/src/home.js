import React, {Component} from 'react'
import {addUser} from './action';
import { connect } from 'react-redux';

class Home extends Component{
    render(){
        return(
            <div>
                <input id="userName" type="text"></input>
                <button onClick={ () => {this.props.addUser(document.getElementById("userName").value)}}>Submit</button>
            </div>
        )
    }
}

function mapStateToProps(state){
    return {...state}
}

function mapDispatchToProps(dispatch) {
    return {
        addUser: (user) => dispatch(addUser(user)),
      }
}

export default connect(mapStateToProps, mapDispatchToProps)(Home)