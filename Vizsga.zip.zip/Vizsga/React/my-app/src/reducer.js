import { ADDUSER, ADDQUESTION } from "./action";


const questions = {
    user:[],
    myQuestions: [{
        title: "Működik?",
        text: "Vajon működik-e az oldal?",
        tags: "Redux",
        answers: [
            {
                user: "Ricsi",
                text: "YES",
            },
            {
                user: "Tibi",
                text: "YES",
            },
            {
                user: "Geri",
                text: "YES",
            }
        ]
    }],
    question: [
        {
            title: "test",
            asker: "25BAM",
            text: "Testing the redux store",
            tags: "react, redux"
        },
        {
            title: "test",
            asker: "25BAM",
            text: "Testing the redux store",
            tags: "react, redux"
        },
        {
            title: "test",
            asker: "25BAM",
            text: "Testing the redux store",
            tags: "react, redux"
        },
        {
            title: "test",
            asker: "25BAM",
            text: "Testing the redux store",
            tags: "react, redux"
        },
    ],
    
}


export default function reducer(state = questions,  action) {
    const newState = {};
    newState.user = [...state.user]
    newState.question = [...state.question];
    switch(action.type) {
        case ADDUSER: 
        newState.user.push(action.user)
        return {
            ...state,
            user: newState.user
            }

        case ADDQUESTION: 
        newState.question.push(action.question)
        return {
                ...state,
                question: newState.question
                }
        
        default : return {
            ...state
        }
    }
}