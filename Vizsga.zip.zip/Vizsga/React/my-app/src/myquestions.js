import React, {Component} from 'react'
import {addQuestion} from './action';
import { connect } from 'react-redux';

class MyQuestions extends Component{
    render(){
        return(
            <div>
                {this.props.myQuestions.map(question =>{
                    return(
                        <div>
                            <div>
                            <h4>{question.title}</h4>
                            <p>{question.text}</p>
                            <p>{question.tags}</p>
                        </div>
                        {question.answers.map(answer=>{
                            return(
                                <div>
                                    <p>{answer.user}</p>
                                    <p>{answer.text}</p>
                                </div>
                            )
                        })}
                        </div>
                    )
                })}
            </div>
        )
    }
}

function mapStateToProps(state){
    return {...state}
}

function mapDispatchToProps(dispatch) {
    return {
        addQuestion: (username, title, text, tags) => dispatch(addQuestion(username, title, text, tags)),
      }
}

export default connect(mapStateToProps, mapDispatchToProps)(MyQuestions)