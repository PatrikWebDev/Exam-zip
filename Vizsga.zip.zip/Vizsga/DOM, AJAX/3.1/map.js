const map = document.getElementById("map")
const sor = document.getElementById("sor")
const oszlop = document.getElementById("oszlop")
const newMap = document.getElementById("newMap")

newMap.addEventListener("click", mapGeneration())

function mapGeneration(){

}
