class ApplicantStatusController {
    constructor(Applicantservice){
        this.service = Applicantservice
    }

    applicantStatusChange(req, res){
        this.service.applicantStatusChange({
            rowid: req.body.rowid,
            changeType: req.body.changeType,
            hrPerson: req.body.hrPerson
        })
        res.redirect("/applicants")
    }
}

module.exports={
    ApplicantStatusController
}