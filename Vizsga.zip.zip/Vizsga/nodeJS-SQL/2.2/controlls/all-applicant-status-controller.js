class AllApplicantController {
    constructor(Applicantservice) {
        this.applicantService = Applicantservice
    }

    applicantSorting(results){
        const newApplicant = []
        const firstRoundApplicant = []
        const acceptedApplicant =[]
        const deniedApplicant = []
        for(const applicant of results){
            if(applicant.status === "new") newApplicant.push(applicant)
            if(applicant.status === "first") firstRoundApplicant.push(applicant)
            if(applicant.status === "accepted") acceptedApplicant.push(applicant)
            if(applicant.status === "denied") deniedApplicant.push(applicant)    
        }

        return {newApplicant, firstRoundApplicant, acceptedApplicant, deniedApplicant}

    }

    async allApplicants(req, res) {
        const results = await this.applicantService.allApplicant()
        const sortedApplicants = this.applicantSorting(results)
        let {newApplicant, firstRoundApplicant, acceptedApplicant, deniedApplicant} = sortedApplicants
        res.render('all-applicant', {newApplicant, firstRoundApplicant, acceptedApplicant, deniedApplicant})

    }

  async  changeAbleApplicants(req, res) {
        const results = await this.applicantService.allApplicant()
        const hrResults = await this.applicantService.allHR()
        const sortedApplicants = this.applicantSorting(results)
        let {newApplicant, firstRoundApplicant} = sortedApplicants
        let applicant = [...newApplicant, ...firstRoundApplicant]

        res.render('selection', {applicant, hrResults})

    }

}

module.exports = {
    AllApplicantController
}