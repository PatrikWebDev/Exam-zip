class HrController {
    constructor(Applicantservice) {
        this.service = Applicantservice
    }
    applicantSorting(results) {
        const firstRoundApplicant = []
        const acceptedApplicant = []
        const deniedApplicant = []
        if (!(Array.isArray(results))) results = [results]
        for (const applicant of results) {
            if (applicant.status === "first") firstRoundApplicant.push(applicant)
            if (applicant.status === "accepted") acceptedApplicant.push(applicant)
            if (applicant.status === "denied") deniedApplicant.push(applicant)
        }

        return { firstRoundApplicant, acceptedApplicant, deniedApplicant }

    }

    async    allHR(req, res) {
        const hrPersons = await this.service.allHR()
        res.render("status", { hrPersons })
    }

    async    specificHR(req, res) {
        const results = await this.service.specificHR({ name: req.body.int })
        const sortedApplicants = this.applicantSorting(results)
        let { firstRoundApplicant, acceptedApplicant, deniedApplicant } = sortedApplicants
        res.render("statistics", { firstRoundApplicant, acceptedApplicant, deniedApplicant })
    }
}

module.exports = {
    HrController
}