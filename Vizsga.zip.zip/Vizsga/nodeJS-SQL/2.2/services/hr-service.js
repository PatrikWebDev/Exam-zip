class HRService {
    constructor(applicantRepository) {
        this.applicantRepository = applicantRepository;
    }

    async    allHR() {
        try {
            const results = await this.applicantRepository.allHR()
            return results
        } catch (err) {
            return err
        }
    }

    async    specificHR(data) {
        try {
            const results = await this.applicantRepository.specificHR(data)
            return results
        } catch (err) {
            return err
        }
    }

}


module.exports = {
    HRService
}