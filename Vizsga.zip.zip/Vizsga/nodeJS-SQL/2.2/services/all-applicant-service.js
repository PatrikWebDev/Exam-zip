class AllApplicantService {
    constructor(applicantRepository) {
        this.applicantRepository = applicantRepository;
    }

    async    allApplicant() {
        try {
            const results = await this.applicantRepository.allApplicant()
            return results
        } catch (err) {
            return err
        }
    }

    async    allHR() {
        try {
            const results = await this.applicantRepository.allHR()
            return results
        } catch (err) {
            return err
        }
    }

}


module.exports = {
    AllApplicantService
}