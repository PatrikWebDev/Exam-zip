const sqlite3 = require('sqlite3')
const db = new sqlite3.Database('Repository.db')

function creation(){db.serialize(function () {
    db.run('CREATE TABLE IF NOT EXISTS applicants (name VARCHAR(100) NOT NULL, email VARCHAR(100) NOT NULL, status VARCHAR(20) NOT NULL, hrPerson VARCHAR(100))')
    db.run('INSERT INTO applicants ( name, email, status) VALUES ("Tibor Marosi", "tibor@gmail.com", "new")')
    db.run('INSERT INTO applicants ( name, email, status) VALUES ("Csaba Marosi", "csaba@gmail.com", "first")')
    db.run('INSERT INTO applicants ( name, email, status, hrPerson) VALUES ("Gergő Marosi", "gergő@gmail.com", "accepted", "GEri Marosi" )')
    db.run('INSERT INTO applicants ( name, email, status, hrPerson) VALUES ("Péter Marosi", "peti@gmail.com", "denied", "Tibor Marosi")')

    db.run('CREATE TABLE IF NOT EXISTS hrPerson (name VARCHAR(100) NOT NULL, id VARCHAR(20) NOT NULL)')
    db.run('INSERT INTO hrPerson ( name, id) VALUES ("Tibor Marosi", "1")')
    db.run('INSERT INTO hrPerson ( name, id) VALUES ("GEri Marosi", "2")')
    db.run('INSERT INTO hrPerson ( name, id) VALUES ("Gréta Marosi", "3")')
    db.run('INSERT INTO hrPerson ( name, id) VALUES ("Tibor Marosi", "4")')

})}

creation()