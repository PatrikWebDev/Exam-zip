const sqlite3 = require('sqlite3')
const db = new sqlite3.Database('Applicant.db')

function creation(){db.serialize(function () {
    db.run('CREATE TABLE applicants (name VARCHAR(100) NOT NULL, email VARCHAR(100) NOT NULL, status VARCHAR(20) NOT NULL)')
    db.run('INSERT INTO applicants ( name, email, status) VALUES ("Tibor Marosi", "tibor@gmail.com", "new")')
    db.run('INSERT INTO applicants ( name, email, status) VALUES ("Csaba Marosi", "csaba@gmail.com", "first")')
    db.run('INSERT INTO applicants ( name, email, status) VALUES ("Gergő Marosi", "gergő@gmail.com", "accepted")')
    db.run('INSERT INTO applicants ( name, email, status) VALUES ("Péter Marosi", "peti@gmail.com", "denied")')
})}

creation()