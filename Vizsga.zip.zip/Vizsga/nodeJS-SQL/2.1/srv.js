const express = require('express');
const exphbs  = require('express-handlebars');
const bodyParser = require('body-parser')
const app = express();
 
app.engine('handlebars', exphbs());
app.set('view engine', 'handlebars');
app.use(bodyParser.urlencoded({ extended: true }))

const NewApplicantController = require('./controlls/new-applicant-controller').NewApplicantController
const NewApplicantService = require('./services/new-applicant-service').NewApplicantService
const ApplicantRepository = require('./repositories/repository').ApplicantRepository

const newApplicantController = new NewApplicantController(new NewApplicantService(new ApplicantRepository()))

const AllApplicantController = require('./controlls/all-applicant-status-controller').AllApplicantController
const AllApplicantService = require('./services/all-applicant-service').AllApplicantService

const allApplicantController = new AllApplicantController(new AllApplicantService(new ApplicantRepository()))


const ApplicantStatusController = require('./controlls/applicant-status-controller').ApplicantStatusController
const ApplicantService = require('./services/applicant-status-change-service').ApplicantService

const applicantStatusController = new ApplicantStatusController(new ApplicantService(new ApplicantRepository()))
 
app.get('/', function (req, res) {
    res.render('home');
});

app.post('/apply', newApplicantController.newApplicantRegister.bind(newApplicantController))

app.get('/applicants', allApplicantController.allApplicants.bind(allApplicantController))

app.get('/applicantStatusChange', allApplicantController.changeAbleApplicants.bind(allApplicantController))
app.post('/applicantStatusChange', applicantStatusController.applicantStatusChange.bind(applicantStatusController))
 
app.listen(3000, ()=> console.log("Server started"));