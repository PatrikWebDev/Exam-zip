const sqlite3 = require('sqlite3')
const db = new sqlite3.Database('Applicant.db')

class ApplicantRepository {
    allApplicant() {
        return new Promise((resolve, reject) => {
            db.serialize(function () {
                db.all('SELECT name, email, status, rowid FROM applicants', (err, result) => {
                    if (err) {
                        reject(err);
                        return
                    }
                    resolve(result)
                })
            })
        })
    }

    applicantStatusChange(data){
        db.serialize(function () {
            db.run(`UPDATE applicants SET status = "${data.changeType}" WHERE rowid = ${data.rowid}`)
        })

    }


    registerNewApplicant(applicants) {
        db.serialize(function () {
            db.run(`INSERT INTO applicants ( name, email, status) VALUES ("${applicants.name}", "${applicants.email}", "new")`)
        })
    }
}

module.exports = {
    ApplicantRepository
}
