class ApplicantService {
    constructor(applicantRepository) {
        this.applicantRepository = applicantRepository;
    }

    applicantStatusChange(applicantData){
        this.applicantRepository.applicantStatusChange(applicantData)
    }
}


module.exports = {
    ApplicantService
}