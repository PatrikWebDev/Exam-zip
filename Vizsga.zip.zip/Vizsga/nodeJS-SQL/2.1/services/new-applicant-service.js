class NewApplicantService {
    constructor(applicantRepository) {
        this.applicantRepository = applicantRepository;
    }

    newApplicant(applicantData){
        this.applicantRepository.registerNewApplicant(applicantData)
    }
}


module.exports = {
    NewApplicantService
}