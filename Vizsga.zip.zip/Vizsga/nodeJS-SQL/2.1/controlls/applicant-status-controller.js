class ApplicantStatusController {
    constructor(Applicantservice){
        this.service = Applicantservice
    }

    applicantStatusChange(req, res){
        this.service.applicantStatusChange({
            rowid: req.body.rowid,
            changeType: req.body.changeType
        })
        res.redirect("/applicants")
    }
}

module.exports={
    ApplicantStatusController
}