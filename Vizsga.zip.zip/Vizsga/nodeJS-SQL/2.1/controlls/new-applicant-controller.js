class NewApplicantController {
    constructor(Applicantservice){
        this.applicantservice = Applicantservice
    }

    newApplicantRegister(req, res){
        this.applicantservice.newApplicant({
            name: req.body.applicantName,
            email: req.body.applicantEmail
        })
        res.redirect("/applicants")
    }
}

module.exports={
    NewApplicantController
}